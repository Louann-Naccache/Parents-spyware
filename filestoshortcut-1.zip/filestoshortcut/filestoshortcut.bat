
@echo off
for %%F in (".\*.*") do (
  for /f "delims=." %%A in ("%%F") do set "first=%%A";
  echo %first%;
  
  powershell -NoProfile -Command "$s = (New-Object -ComObject WScript.Shell).CreateShortcut('"%first%".lnk'); $s.TargetPath = '.\'; $s.Save()";
)
